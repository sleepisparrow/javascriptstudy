Promise는 **비동기로 실행된 작업의 결과**를 나타내는 객체임
```Javascript
let promise = new Promise(function(resolve, reject) {
	//doing something!
});
```
parameter : `executer` -> resolve() or reject()를 실행함
1. 성공시 value를 반환하는 함수 실행
2. 실패시 error를 반환하는 함수 실행

## 상태
1. Pending
	실행중인 상태
2. Fulfilled
	resolve가 실행된, 성공한 상태
3. Rejecter
	reject가 실행된, 실패한 상태
4. Settled
	어떠한 상태든, 모든 프로세스가 끝난 상태

## then, catch, finally
### 1. then
`then`은 이전 `Promise`객체를 받아 처리해주는 함수

기본 형태:
```Javascript
// p = Promise 객체
// onFulfilled, onRejected는 모두 함수임
p.then(
	onFulfilled, // 성공함
	onRejected   // 실패함
	);

p.then(
	onFulfilled
);

// returns Promise
```

일반적인 예시는 다음과 같음

```Javascript
// p = Promise 객체
p.then(res => {
	console.log(val);
});

// ==
p.then( console.log );
```
이게 되는 이유는 console.log 역시 파라미터가 하나인 함수이기에 문제 없이 된다고 한다. 

### 2. catch
`catch`는 `Promise` 객체에서 에러가 났을 경우, 받아 처리해주는 함수

기본 형태:
```js
p.catch(onRejected);

// returns Promise
```

결국, try-catch 에서의 catch와 비슷한 역할을 한다고 할 수 있다.

### 3. finally
`finally`는 `Promise`의 작업이 끝이 나면, `then`이나 `catch` 이전에 반드시 먼저 실행되는 친구임.

기본 형태
```js
p.finally(onFinally);

// returns Promise
```
**주의해야 할 점** 
	- `finally`도 놀랍게도 `Promsie`를 리턴한다. 이는 Promise Chaining이 가능하도록 해준다.
	- `then`, `catch`의 실시 여부와는 관계없이 진행되는 친구이다.
예시
```js
p
	.finally(() => console.log("f1"))
	.then(() => console.log("t1"))
	.finally(() => console.log("f2"));

/* result 
f1
t1
f2
*/
```
이런 식으로 말이다.

## Promise Chaining
// 기본 자료: https://ko.javascript.info/promise-chaining

### 1. 문제점
기본적으로 여러개의 비동기 함수를 순차적으로 불러와야 하는 경우, 어떻게 해야 성공적으로 비동기 함수 처리가 가능할까?

### 2 해결법: Promise Chaining
바로 `then`, `catch`, `finally`가 모두 Promise를 리턴한다는 사실을 이용해서 가능할 수 있다. 
기본적으로, then, catch, finally는 모두 Promise를 리턴하고, 거기에서 발생한 에러나 return value를 Promise에 실어 보낸다.
따라서 then, catch, finally 다음에 바로 또다시 이걸 반복하는 식으로 비동기 함수들을 처리하면 되지 않을까? 이게 바로 Promsie Chaining이다.

예제를 보자.
```js

new Promise(function(resolve, reject) {
  setTimeout(() => resolve(1), 1000); // (*)
}).then(function(result) { // (**)
  alert(result); // 1

  return result * 2;
}).then(function(result) { // (***)
  alert(result); // 2

  return result * 2;
}).then(function(result) {
  alert(result); // 4

  return result * 2;
});

/* result
1 
(1 창이 꺼지고 난 후)2
(2 창이 꺼지고 난 후)4
*/
```
이런 식으로 하는 것을 Promise Chaining이라고 한다! 이때, 그냥 값이 아닌 새로운 Promise를 리턴함으로서, 순차적인 비동기 함수 처리가 가능해진다고 한다!

계속 공부할 자료들
1. JS 비동기 함수 메인포스팅
   https://gruuuuu.github.io/javascript/async-js/