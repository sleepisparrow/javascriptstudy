Promise는 **비동기로 실행된 작업의 결과**를 나타내는 객체임
```Javascript
let promise = new Promise(function(resolve, reject) {
	//doing something!
});
```
parameter : `executer` -> resolve() or reject()를 실행함
1. 성공시 value를 반환하는 함수 실행
2. 실패시 error를 반환하는 함수 실행

## 상태
1. Pending
	실행중인 상태
2. Fulfilled
	resolve가 실행된, 성공한 상태
3. Rejecter
	reject가 실행된, 실패한 상태
4. Settled
	어떠한 상태든, 모든 프로세스가 끝난 상태

## then, catch, finally
### 1. then
`then`은 이전 `Promise`객체를 받아 처리해주는 함수

기본 형태:
```Javascript
// p = Promise 객체
// onFulfilled, onRejected는 모두 함수임
p.then(
	onFulfilled, // 성공함
	onRejected   // 실패함
	);

p.then(
	onFulfilled
);

// returns Promise
```

일반적인 예시는 다음과 같음

```Javascript
// p = Promise 객체
p.then(res => {
	console.log(val);
});

// ==
p.then( console.log );
```
이게 되는 이유는 console.log 역시 파라미터가 하나인 함수이기에 문제 없이 된다고 한다. 

### 2. catch
`catch`는 `Promise` 객체에서 에러가 났을 경우, 받아 처리해주는 함수

기본 형태:
```js

```

// 오늘 공부는 여기까지. 
계속 공부할 자료들
1. 프라미스 체이닝
   https://ko.javascript.info/promise-chaining
2. Promise 주교재 
   https://gruuuuu.github.io/javascript/promise/
3. JS 비동기 함수 메인포스팅
   https://gruuuuu.github.io/javascript/async-js/
4. Promise 객체 사전.
   https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Promise/catch