#javascript #async_programing
# 1. 왜 나왔는가?
[[Promise#Promise Chaining]]을 이용해서 비동기 함수를 연속적으로 실시하는 것은 여전히 가독성이 떨어지기 때문이다.
eg)
```js
let a = new Promise(function(resolve, reject) {
	resolve(1);
}); 
a.then((resolve) => {
	return new function(resolve, reject) {
		resolve(2);
	});
}).then((resolve) => {
	... // 똑같은 내용
})...;
```
이런 식으로 코딩의 가독성이 꽤 떨어지는 모습을 보인다. 
이래서 나온 것이 async/await이다.

# 2. 사용법
## async
async는 Promsie객체를 리턴할 때, 더 쉽게 하기 위해 붙이는 수식어이다.
그래서 밑의 두 코드는 같다.
```js
function A() {
	return new Promise((resolve, reject) => {
		return resolve(1);
	});
}

A().then(console.log);
```

```js
async function A() {
	return 1;
}

A().then(console.log);
```

## await